# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['covid_data_pipeline_ingestion']

package_data = \
{'': ['*'], 'covid_data_pipeline_ingestion': ['.ipynb_checkpoints/*', 'data/*']}

setup_kwargs = {
    'name': 'covid-data-pipeline-ingestion',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Douglas T. S. Leite',
    'author_email': 'dtsleite@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
